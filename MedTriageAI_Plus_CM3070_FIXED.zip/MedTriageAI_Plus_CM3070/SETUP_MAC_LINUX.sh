#!/bin/bash

# MedTriageAI+ Setup Script for macOS and Linux
# Automated setup for Mac/Linux systems

echo ""
echo "============================================"
echo "MedTriageAI+ Setup for macOS/Linux"
echo "============================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python3 not found!"
    echo "Please install Python 3.8+ from https://www.python.org"
    exit 1
fi

echo "[1/5] Python found: $(python3 --version)"

echo "[2/5] Creating virtual environment..."
python3 -m venv venv
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to create virtual environment"
    exit 1
fi

echo "[3/5] Activating virtual environment..."
source venv/bin/activate

echo "[4/5] Installing dependencies..."
pip install --upgrade pip setuptools wheel
pip install -r REBUILD_requirements.txt
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    echo "Make sure you have internet connection"
    exit 1
fi

echo "[5/5] Creating data directories..."
mkdir -p data
mkdir -p models
mkdir -p evaluation

echo ""
echo "============================================"
echo "Setup Complete!"
echo "============================================"
echo ""
echo "To run the application:"
echo "  1. Activate environment: source venv/bin/activate"
echo "  2. Run: streamlit run REBUILD_app.py"
echo "  3. The app will open in your browser at http://localhost:8501"
echo ""
echo "To use the app next time:"
echo "  1. Run: source venv/bin/activate"
echo "  2. Run: streamlit run REBUILD_app.py"
echo ""
